ncerdos = int(input("Cuantos cerdos quieres "))

njamon = ncerdos *4

print("Sacarias de los", ncerdos,"cerdos,", njamon,"jamones, que aproveche :)")
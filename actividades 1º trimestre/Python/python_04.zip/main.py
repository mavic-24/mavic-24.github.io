nombre = (input("cual es tu nombre? "))
edad = int(input("cual es tu edad "))

print("hola",nombre, ",tienes", edad, "años")
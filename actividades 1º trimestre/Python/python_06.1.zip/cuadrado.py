n1 = int(input("dime cuanto mide el lado "))

area = n1* n1

print(area)
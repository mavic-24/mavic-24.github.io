r = int(input("dime el radio "))

area = r*r*3.14159

print(area)
l = int(input("dime el lado de la figura "))
n = int(input("dime el numero de lados(mayor o igual que 5) "))
a = int(input("dime el apotema"))
print("")
if n >= 5 :
    perimetro = l*n
    area = (perimetro*a)/2
    print("el area de la figura es",area)
else:
    print("te he dicho que los lados tienen que ser mayor o igual que 5")


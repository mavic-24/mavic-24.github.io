n1 = int(input("dime un numero "))
n2 = int(input("dime otro numero "))
n3 = int(input("dime un ultimo numero "))

resta = n1- n2 -n3

print(resta)
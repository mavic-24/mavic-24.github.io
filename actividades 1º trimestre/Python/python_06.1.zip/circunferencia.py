C = int(input("dime longitud de la circunferencia "))

diametro= C/3.14159

print ( diametro)
b = int(input("dime la base "))
h = int(input("dime la altura "))

area = (b*h)/2

print (area)
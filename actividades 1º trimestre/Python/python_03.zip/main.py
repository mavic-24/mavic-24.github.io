nombre = "Victor"

print("mi nombre es ", nombre)
num1 = int(input("dime un numero "))

if num1 % 2 == 0 :
    print("El numero es par")
else:
    print("el numero es impar")
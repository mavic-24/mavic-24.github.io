edad = int(input("cuantos años tienes "))
if edad >= 16 :
    renta = int(input("cuanto cobras? "))
    if renta >= 1000:
        print("tienes que tributar")
    else:
        print("no tienes que tributar")
else:
    print("no tienes que tributar")
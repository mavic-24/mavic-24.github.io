edad = int(input("cuantos años tienes? "))

if edad < 4:
    print("tienes que pagar 4$")
elif 18>edad>=4 :
    print("tienes que pagar 5$")
elif edad>=18 :
    print("tienes que pagar 10$")
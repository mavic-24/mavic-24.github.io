edad = int(input("cual es tu edad"))

if edad >= 18 : 
    print("Felicidadaes, eres mayor de edad, pasa")
else : 
    print("No puedes entrar en la disco, tira a casa")
    
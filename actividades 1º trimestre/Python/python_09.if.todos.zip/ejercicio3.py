num1 = int(input("Dime un numero "))
num2 =  int(input("Dime otro "))

if num2 == 0 : 
    print("ERROR, NO SE PUEDE")
else :
    print("el resultado es ",num1/num2)
tipo = input("que tipo de pizza quieres, vegetariana o no vegetariana ")

if tipo == "vegetariana":
    ingr = input("dime que quieres: pimiento o  tofu ")
elif tipo == "no vegetariana":
    ingr = input("dime que quieres: peperoni, jamon o salmon ")
print("")  
print("tienes una pizza",tipo,"tiene mozzarella, tomate y", ingr)    
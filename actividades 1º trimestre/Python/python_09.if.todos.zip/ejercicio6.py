nombre = input("cual es tu nombre ")
genero = input("que eres ")
inicial = nombre.strip()[0].lower()

if genero == "hombre" : 
    if inicial < "n" :
        print("eres del grupo B")
    else :
        print("Tu eres del grupo A")
else : 
    if inicial > "m" :
        print("eres del grupo B")
    else :
        print("Tu eres del grupo A")
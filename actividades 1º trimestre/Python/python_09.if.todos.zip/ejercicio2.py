contraseña = "Pepito grillo"

acierto = input("cual crees que es la contraseña? ")

if contraseña == acierto : 
    print("Oye pues muy bien, bien sabida")
else :
    print("Equivocado,no puedes entrar al tobogan")
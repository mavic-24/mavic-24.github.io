puntuacion = float(input("dime que puntuacion te puso la empresa (0,0.4,0.6) "))
dinero = 2400
if puntuacion == 0 :
    print("tu nivel es inaceptable, cobraras",dinero*puntuacion)
elif puntuacion == 0.4 :
    print("tu nivel es aceptable, cobraras",dinero*puntuacion)
elif puntuacion == 0.6 :
    print("tu nivel es meritorio, cobraras",dinero*puntuacion)    
else:
    print("eso es imposible, te vamos a despedir por mentiroso")
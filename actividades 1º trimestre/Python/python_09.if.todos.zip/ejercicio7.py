d = int(input("cuanto cobras "))

if d <10000 :
    print("tu tipo impositivo es del 5%")
elif 20000> d >= 10000 :
    print("tu tipo impositivo es del 15%")
elif 35000> d >= 20000 :
    print("tu tipo impositivo es del 20%")        
elif 60000> d >= 35000 :
    print("tu tipo impositivo es del 30%")        
elif  d >= 60000 :
    print("tu tipo impositivo es del 45%")            
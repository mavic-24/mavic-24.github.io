ahorro = 100

print(ahorro)
print("")
ahorro_mensual = 10
num_meses = 4

ahorros_nuevos = ahorro_mensual * num_meses

ahorro_total = ahorro + ahorros_nuevos

print(ahorro_total)
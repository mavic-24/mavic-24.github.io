ahorro = 100


print("")
ahorro_mensual = 10
num_meses = 4

ahorros_nuevos = ahorro_mensual * num_meses

ahorro_total = ahorro + ahorros_nuevos

print(type(ahorro_total))

intro = hola
intro2 = intro + intro

#no se puede porque estas sumando palabras y no numeros
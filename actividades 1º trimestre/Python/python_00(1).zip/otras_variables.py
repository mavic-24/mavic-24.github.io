mitad = 0.5
introduccion = "¡Hola, como estas!"
is_good = True

print(mitad)
print(introduccion)
print(is_good)
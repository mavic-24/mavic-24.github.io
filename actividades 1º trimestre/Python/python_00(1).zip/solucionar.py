# Definicion de ahorros y ahorros_totales
ahorros = 100
ahorros_totales = 150
str(ahorros)
str(ahorros_totales)
# Formatear la salida
print("Empece con €",  ahorros ," y ahora tengo €"  ,ahorros_totales  ,". Brutal!")
# Definicion of pi_string
pi_string = "3.1415926"
# Convertir pi_string a float: pi_float
pi_float = float(pi_string)



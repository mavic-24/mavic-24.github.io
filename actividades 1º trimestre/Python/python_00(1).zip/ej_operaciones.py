print(4+5)
print(5-5)
print(3*5)
print(10/2)